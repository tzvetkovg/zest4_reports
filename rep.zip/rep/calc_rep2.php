<?php
include_once('C:\xampp\login_mysql\db_connect.php');
include_once('C:\xampp\login_mysql\functions.php');
include_once('C:\xampp\oracle\db_connect.php');
include ('C:\xampp\htdocs\rep\ChromePhp.php');
sec_session_start();
		
	$mobile=$_POST['mobi'];
	
	$sql  = "SELECT * FROM early_termination_calc_rep2 where mobile_no in (" . $mobile . ")" ;
	$stmt = oci_parse ($conn, $sql);
  
	//Execute
	oci_execute ($stmt);

	  //Start building the table
	  $displayResults = '<table id="mytable" class="display cell-border compact" style="width: 100%;" >';
	  $displayResults .= '<thead><tr> 
						   <th> MOBILE_NO </th> 
						   <th> CUSTOMER_NO </th> 
						   <th> BIL_GROUP </th> 
						   <th> USERNAME </th> 
						   <th> NETWORK </th> 
						   <th> DATE_FROM </th> 
						<th> Disconnection_Date </th> 
						   <th> NEXT_UPGRADE_DATE </th> 
						   <th> TARIFF_NAME </th> 
						   <th> TARIFF_AMOUNT </th> 
						   <th> SUM_BOLT_ONS </th> 
						   <th> MONTHS_REMAINING </th> 
						   <th> DAYS_IN_LAST_MONTH </th>
						<th> DAYS_IN_Disconnection_MONTH </th> 
						   <th> ETF </th>
						   <th> DISCONNECTION_FEE </th> 
						   <th> TOTAL_DUE </th>
						  </tr></thead>';
      $displayResults .= '<tbody>'; 
    //Get json FcCodesb
	$string = file_get_contents("FCcodes.json");
	$json_a = json_decode($string, true);
	//Get Disconnection fees - json
	$string2 = file_get_contents("Disconnection_fee.json");
	$disconnetion_lookup = json_decode($string2, true);
	
	$boltOn = 0;
	$mobile_no = 0;
	$count = false;
	$tariffAmount = 0;
	$fcCodeNotInjected = false;
	$TariffName = "";
	
	$nrows = oci_fetch_all($stmt, $results);
	
	$stmt = oci_parse ($conn, $sql);
	oci_execute ($stmt);
	//ChromePhp::log('rows' . $nrows);
  //Get Values
	while ($row = oci_fetch_assoc($stmt)) {
		
		//Reset values for the next mobile number in the list
		if (($mobile_no != $row['MOBILE_NO']) && ($count == "true")){
			drawRow($rowVal, $TariffName, $boltOn, $tariffAmount,$fcCodeNotInjected);
			$boltOn = 0;
			$tariffAmount = 0;
			$TariffName = "";
			$fcCodeNotInjected = false;
		}
		//Check whether it's a tariff
		if ($row['TYPE'] == "Tariff"){
			//If tariff exists in the json file
			if(array_key_exists($row['CODE'], $json_a)) {
				$tariffAmount =  $json_a[$row['CODE']];
				$TariffName = $row['TARIFF_NAME'];
			}else{
				$tariffAmount = $row['AMOUNT'];
				$fcCodeNotInjected = true;
			}
		//Check whether it's a bolt on
		}else{
			//If bolt on exists in the json file
			if(array_key_exists($row['CODE'], $json_a)) {
				$boltOn += $json_a[$row['CODE']];
			}else{
				//Sum the bolt ons
				$boltOn += $row['AMOUNT'];
				$fcCodeNotInjected = true;
			}
		}
		//In case the end row is reached if there are more than 1 rows
		if($nrows == oci_num_rows($stmt) && $count){
			drawRow($row, $TariffName, $boltOn, $tariffAmount, $fcCodeNotInjected);
		}
		
		//In case only one row is returned
		if($nrows == 1){
			drawRow($row, $TariffName, $boltOn, $tariffAmount,$fcCodeNotInjected);
			$fcCodeNotInjected = false;
		}
		//Keep track of the mobile numbers rows
		$mobile_no = $row['MOBILE_NO'];
		$count = true;
		//Get values in the row
		$rowVal = $row;
		
	}
   //Draw the table row
   function drawRow($row, $TariffName, $boltOns, $tariffAmount,$fcCodeNotInjected){
		global $disconnetion_lookup, $displayResults;
		
		
		//Checke whether disconnection fee is defined
		if(array_key_exists($row['NETWORK'], $disconnetion_lookup)) {
			$network =  $disconnetion_lookup[$row['NETWORK']];
		}else{
			$network = $row['DISCONNECTION_FEE'];
		}
		
		/*
		//Calculate ETF for days in contract month
		$daily_rate_c = $tariffAmount / $row['NUMBER_OF_DAYS_IN_CONTRACT'];
		
		//Calculate ETF

		$ETF = ($row['MONTHS_REMAINING'] * $tariffAmount) + ($row['DAYS_IN_LAST_MONTH_DISCONN'] * $daily_rate_c) + ($row['DAYS_IN_LAST_MONTH_CONTRACT'] *  $daily_rate_c);
		$ETF = "£" . $ETF;
		//Calculate Total Due
		$Total_Due = ($row['MONTHS_REMAINING'] * $tariffAmount) + ($row['DAYS_IN_LAST_MONTH_DISCONN'] * $daily_rate_c) + ($row['DAYS_IN_LAST_MONTH_CONTRACT'] *  $daily_rate_c) + $network;
		$Total_Due = "£" . $Total_Due;
		
		//************
		
		//Calculate ETF for days in disconnection month
		$daily_rate_d = $tariffAmount / $row['NUMBER_OF_DAYS_IN_DISCONN'];
		//Calculate ETF
		$ETF = ($row['MONTHS_REMAINING'] * $tariffAmount) + ($row['DAYS_IN_LAST_MONTH_DISCONN'] * $daily_rate_d) + ($row['DAYS_IN_LAST_MONTH_CONTRACT'] *  $daily_rate_d);*/
		
		
		//Calculate ETF for days in contract month
		ChromePhp::log('TariffName ' . $TariffName);
		ChromePhp::log('tariffAmount ' . $tariffAmount);
		$daily_rate_c = ($tariffAmount + $boltOns) / $row['NUMBER_OF_DAYS_IN_CONTRACT'];
		$charge_contract = $row['DAYS_IN_LAST_MONTH_CONTRACT'] *  $daily_rate_c;
		
		ChromePhp::log('daily_rate_c  ' . $daily_rate_c);
		
		ChromePhp::log('charge_contract  ' . $charge_contract);
		
		//Calculate ETF for days in disconnection month
		$daily_rate_d = ($tariffAmount + $boltOns) / $row['NUMBER_OF_DAYS_IN_DISCONN'];
		$charge_disconnection = $row['DAYS_IN_LAST_MONTH_DISCONN'] * $daily_rate_d;
		
		//Calculate main tariff charge
		$charge_months_remaining = $row['MONTHS_REMAINING'] * ($tariffAmount + $boltOns);
		
		$ETF = $charge_contract + $charge_disconnection  + $charge_months_remaining;
		//ChromePhp::log($ETF . "  " . intval($network));
		
		$Total_Due = round($ETF,2) + intval($network);
		$ETF = "£" . round($ETF,2);	
		$Total_Due = "£" . $Total_Due;

		
	//Define class based on whether bolt ons or tariff is found in the json files
	if ($fcCodeNotInjected)
		$class = "red";
	else
		$class = "normal";
		
	$displayResults .= '<tr class="' . $class . '">
					<td>' . $row['MOBILE_NO'] . '</td> 
					<td>' . $row['CUSTOMER_NO'] . '</td> 
					<td>' . $row['BIL_GROUP'] . '</td> 
					<td>' . $row['USERNAME'] . '</td> 
					<td>' . $row['NETWORK'] . '</td> 
					<td>' . $row['DATE_FROM'] . '</td>
					<td>' . $row['DATE_TO'] . '</td> 					
					<td>' . $row['NEXT_UPGRADE_DATE'] . '</td> 
					<td>' . $TariffName . '</td> 
					<td>' . $tariffAmount . '</td> 
					<td>' . $boltOns . '</td> 
					<td>' . $row['MONTHS_REMAINING'] . '</td> 
					<td>' . $row['DAYS_IN_LAST_MONTH_CONTRACT'] . '</td>
					<td>' . $row['DAYS_IN_LAST_MONTH_DISCONN'] . '</td> 
					<td>' . $ETF . '</td> 
					<td>' . $network . '</td> 
					<td>' . $Total_Due . '</td>
				</tr>';
   }
   
	//Finish the table
    $displayResults .= '</tbody></table>';
  
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="Some content here" />
	<meta name="keywords" content="axon" />

	<title>ETF</title>
	<link rel="shortcut icon" href="src/images/sort_asc.png" />
	<link rel="shortcut icon" href="src/images/sort_both.png" />
	<link rel="stylesheet" href="src/jquery-ui.min.css" type="text/css" />
	<link rel="stylesheet" href="src/chosen.min.css" type="text/css" />
	<link rel="stylesheet" href="src/dataTables.tableTools.min.css" type="text/css" />
	
	<link rel="stylesheet" href="src/jquery.dataTables.min.css" type="text/css" />
		<link rel="stylesheet" href="src/jquery.dataTables_themeroller.css" type="text/css" />
	<script src="src/jquery-1.11.1.min.js"></script>
	<script src="src/jquery-ui.min.js"></script>
	<script src="src/jquery.dataTables.min.js"></script>
	<script src="src/chosen.jquery.min.js"></script>
	<script src="src/dataTables.tableTools.min.js"></script>
	
	
<style>
.dataTables_wrapper { font-size: 13px }

.red{
	color: red;
}

</style>	
</head>
<body style="background-color: 	#D6D6C2;">

	 <a href="http://192.168.200.225/rep/report2.php">back to search</a>

	<div id="table"> 
		<?php
			 echo $displayResults;
		?>
	</div>
	
	
	
</body>
</html>

<script>
$(document).ready(function () {
		tbl = $('#mytable').DataTable({
		"bAutoWidth": false,
		paging: false,
		 "sDom": 'T<"clear">lfrtip',
		 tableTools: {
            "sRowSelect": "multi",
			 "aButtons":    ["xls", "pdf", "copy", "select_all", "select_none" ]
        }
		
		});
});
</script>


