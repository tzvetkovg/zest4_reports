<?php
include_once('C:\xampp\login_mysql\db_connect.php');
include_once('C:\xampp\login_mysql\functions.php');
include_once('C:\xampp\oracle\db_connect.php');
sec_session_start();


$sql  = "SELECT * FROM early_termination_initial" ;
$stmt = oci_parse ($conn, $sql);
  
  //Execute
  oci_execute ($stmt);
  
  //Get Values
  $selectOptions = "";
  while ($row = oci_fetch_assoc($stmt)) {
				$selectOptions .= "<option value='" . $row['CUSTOMER_NO'] . "'>" . $row['CUSTOMER_NO'] . "</option>";
		}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="Some content here" />
	<meta name="keywords" content="axon" />

	<title>Early Termination Calculator</title>
	<link rel="shortcut icon" href="src/images/sort_asc.png" />
	<link rel="shortcut icon" href="src/images/sort_both.png" />
	<link rel="stylesheet" href="src/jquery-ui.min.css" type="text/css" />
	<link rel="stylesheet" href="src/chosen.min.css" type="text/css" />
	
	<link rel="stylesheet" href="src/jquery.dataTables.min.css" type="text/css" />
		<link rel="stylesheet" href="src/jquery.dataTables_themeroller.css" type="text/css" />
	<script src="src/jquery-1.11.1.min.js"></script>
	<script src="src/jquery-ui.min.js"></script>
	<script src="src/jquery.dataTables.min.js"></script>
	<script src="src/chosen.jquery.min.js"></script>
	
	
<style>
th {
text-align:center
}

td {
text-align:center
}

.highlight{
color:#FF9900;
}
.center {
    margin-left: auto;
    margin-right: auto;
    width: 50%;
	text-align:center;
}
</style>	
</head>
<body bgcolor="#D0D0D0">

	
	<div class="center">
		<label>Please select a customer </label>
		<br>
		<select id="customers" class="chosen" style="width: 150px;"> 
			<?php echo $selectOptions ?>
		</select>
		<br>
		<br>
			<button type="submit" id="submit"> Show numbers </button>
		<br>
		<br>
		<br>
		<div id="resContainer" style="display:none">
			<button type="submit" id="displayResults"> Run Report </button>
			<br>
			<br>
			<br>
			<button id="checkAll"> Check all </button>
			<button id="UncheckAll"> Uncheck all </button>
		</div>
		
		<br>
		<div id="error" style="color:red;display:none;"> Please select some mobile numbers </div>
		<br>
		<br>
		<br>
		
		<div id="results"> </div>
		
	<div>
	
	
	<form id="formResults" action="calc.php" method="post";>
        <input type="hidden" id="mobi" name="mobi">
    </form>
	
</body>

<script>
	var tbl = "";
	//Chosen js lib to the select box
	$(".chosen").chosen({});
	//On submit display results
	$("#submit").click(function(){
		$("#error").css("display","none");
		var dataString = 'customersVal='+ $("#customers").val();
		$.ajax({
			type: "POST",
			url: "process.php",
			data: dataString,
			cache: false,
			success: function(result){
				$("#results").html(result);
				tbl = $('#mytable').DataTable();
				$("#resContainer").css("display","inline");
			}
		});
	});
	//Check all
	$('body').on('click', '#checkAll', function() {
		$('input.check', tbl.rows().nodes()).each( function() {
				$(this).parent().parent().addClass('highlight');
				$(this).closest('td').next().addClass("hel");
				$(this).prop('checked', true);
		} );	
	});
	//UnCheck all
	$('body').on('click', '#UncheckAll', function() {
		$('input.check', tbl.rows().nodes()).each( function() {
				$(this).parent().parent().removeClass('highlight');
				$(this).closest('td').next().removeClass("hel");
				$(this).prop('checked', false);
		} );	
	});
	
	
	//On a single check box click highlight row
	$('body').on('click', 'input.check', function() {
		$(this).parent().parent().toggleClass('highlight');
		$(this).closest('td').next().toggleClass("hel");
	});
	//on run report click
	$("#displayResults").click( function(){
		var ok = false;
		var concatResults = " mobile_no in (";
		var getData = tbl.cells( '.hel' ).data();
		var counter = 0;
		if(getData.length > 0){
			
			ok = true;
			$.each( getData, function( index, value ) {
				if(index == getData.length - 1){
					concatResults = concatResults + "'" + value + "')";
					return false;
				}
				counter = counter + 1;
			if(counter == 997){
				concatResults = concatResults + "'" + value + "') OR mobile_no in ( ";
				counter = 0;
			}
			concatResults = concatResults + "'" + value + "',";

			
			
			});
		}else{
			$("#error").css("display","inline");
		}
		
		if (ok){
			$("#mobi").val(concatResults);
			$("#formResults").submit();
		}		
	});
	
</script>

</html>
  
