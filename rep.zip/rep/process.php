<?php
include_once('C:\xampp\login_mysql\db_connect.php');
include_once('C:\xampp\login_mysql\functions.php');
include_once('C:\xampp\oracle\db_connect.php');
sec_session_start();

	$customerVal=$_POST['customersVal'];
	$sql  = "SELECT * FROM early_termination_mobile where customer_no = :customer" ;
	$stmt = oci_parse ($conn, $sql);
	oci_bind_by_name($stmt, ":customer" , $customerVal);
  
	//Execute
	oci_execute ($stmt);
	
	  $displayResults = '<table id="mytable" class="display cell-border" width="100%" >';
	  $displayResults .= '<thead><tr><th>Select Number</th><th>MOBILE_NO</th><th>Tariff</th><th>Username</th></tr></thead>';
      $displayResults .= '<tbody>'; 
        
          /*  <tr>
                <td>Blah</td>
                <td>Blah More</td>
                <td class="vcenter"><input type="checkbox" id="blahA" value="1"/></td>
            </tr>
            <tr>
                <td>Blah</td>
                <td>Blah More</td>
                <td class="vcenter"><input type="checkbox" id="blahA" value="1"/></td>
            </tr>
            <tr>
                <td>Blah</td>
                <td>Blah More</td>
                <td class="vcenter"><input type="checkbox" id="blahA" value="1"/></td>
            </tr>
        </tbody>
    </table>*/
  //Get Values
  while ($row = oci_fetch_assoc($stmt)) {
				$displayResults .= '<tr><td><input type="checkbox" class= "check" value="' . $row['MOBILE_NO'] . '"/></td><td>' . $row['MOBILE_NO'] . '</td>' . '<td>' . $row['NAME'] . '</td>' . '<td>' . $row['USERNAME'] . '</td> </tr>';
		}
  $displayResults .= '</tbody></table>'; 
  echo $displayResults;
?>






